# Mini Labirint

Jednostavna 2D igra pod nazivom Sahur_labirint napravljena u Godot Engineu.

## Opis igre

Igrac se krece po prostoru i ne moze prolaziti kroz zidove.
Na sceni se nalazi predmet koji igrac moze pokupiti prelaskom preko njega.

## Kontrole

W - gore
S - dolje
A - lijevo
D - desno

Mogu se koristiti i strelice na tipkovnici.

## Elementi igre

- Igrac koristi CharacterBody2D
- Zidovi koriste StaticBody2D
- Predmet koristi Area2D
- Sudari se odreduju pomocu CollisionShape2D
