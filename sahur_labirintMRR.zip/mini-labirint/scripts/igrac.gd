extends CharacterBody2D

@export var brzina: float = 200.0

func _ready() -> void:
	velocity = Vector2.ZERO

func _physics_process(_delta: float) -> void:
	var smjer := Vector2.ZERO

	smjer.x = Input.get_action_strength("idi_desno") - Input.get_action_strength("idi_lijevo")
	smjer.y = Input.get_action_strength("idi_dolje") - Input.get_action_strength("idi_gore")

	if smjer != Vector2.ZERO:
		smjer = smjer.normalized()

	velocity = smjer * brzina
	move_and_slide()
