extends Area2D

var brzina_rotacije = 2.0 

func _process(delta):
	# Rotira predmet u svakom okviru (frame-u)
	rotation += brzina_rotacije * delta
