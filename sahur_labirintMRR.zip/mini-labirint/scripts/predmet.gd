extends Area2D

func _ready() -> void:
	print("Predmet spreman")

func _on_body_entered(body: Node2D) -> void:
	print("USLO JE: ", body.name, " / ", body.get_class())
	queue_free()
